<?php echo $__env->make('frontend.layout.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="layoutSidenav_content">
    <main>
        <?php echo $__env->yieldContent('dashboard'); ?>
        <div class="container-fluid px-4">
<!-- ini untuk content atau main -->
<?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>
</div>

<?php echo $__env->make('frontend.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.layout.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\ecommerce\resources\views/frontend/layout/app.blade.php ENDPATH**/ ?>