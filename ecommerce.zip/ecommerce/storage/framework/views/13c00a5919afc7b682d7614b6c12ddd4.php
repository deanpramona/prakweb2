<h1>
    ini halaman periksa
</h1><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\ecommerce\resources\views/periksa.blade.php ENDPATH**/ ?>