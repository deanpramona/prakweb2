







<?php $__env->startSection('dashboard'); ?>
      <!-- Header-->
      <header class="masthead d-flex align-items-center">
        <div class="container px-4 px-lg-5 text-center">
            <h1 class="mb-1">Stylish Portfolio</h1>
            <h3 class="mb-5"><em>A Free Bootstrap Theme by Start Bootstrap</em></h3>
            <a class="btn btn-primary btn-xl" href="<?php echo e(url('frontend/about')); ?>">Find Out More</a>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\ecommerce\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>