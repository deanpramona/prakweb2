@include('frontend.layout.top')

<div id="layoutSidenav_content">
    <main>
        @yield('dashboard')
        <div class="container-fluid px-4">
<!-- ini untuk content atau main -->
@yield('content')
        </div>
    </main>
</div>
</div>

@include('frontend.layout.menu')
@include('frontend.layout.bottom')